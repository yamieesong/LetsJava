package manager.service.impl;

import manager.entity.Student;
import manager.service.ManagerService;

import java.util.List;

public class ManagerServiceImpl implements ManagerService {

    @Override
    public Student registerStudent(Student student) throws Exception {
        return null;
    }

    @Override
    public Student modifyStudent(Student student) throws Exception {
        return null;
    }

    @Override
    public List<Student> searchStudents(Student student) throws Exception {
        return null;
    }

    @Override
    public boolean deleteStudent(int stdNo) throws Exception {
        return false;
    }

    @Override
    public void closeService() throws Exception {

    }
}
